package com.cg.Employee.dao;

import java.util.List;

import com.cg.Employee.bean.Employee;

public interface IDao {

	Employee addEmployee(Employee employee);

	List<Employee> viewEmployee();

	Employee deleteEmployee(String empId);

	Employee updateEmployee(String empId, Employee employee);

}
