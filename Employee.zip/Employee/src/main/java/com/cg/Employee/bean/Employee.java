package com.cg.Employee.bean;

import java.util.Date;

import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.springframework.data.annotation.Id;

import com.fasterxml.jackson.annotation.JsonFormat;

public class Employee {
	
	@Id
	private String empId;
	@NotNull
	@Size(min=2, message="Name should have atleast 2 characters")
	private String name;
	@JsonFormat(pattern="dd-MM-yyyy")
	private Date doj;
	public Employee() {
		super();
		// TODO Auto-generated constructor stub
	}
	public Employee(String empId, String name, Date doj) {
		super();
		this.empId = empId;
		this.name = name;
		this.doj = doj;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Date getDoj() {
		return doj;
	}
	public void setDoj(Date doj) {
		this.doj = doj;
	}
	

	
}
