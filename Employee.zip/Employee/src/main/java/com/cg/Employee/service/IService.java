package com.cg.Employee.service;

import java.util.List;

import com.cg.Employee.bean.Employee;

public interface IService {

	Employee addEmployee(Employee employee);

	List<Employee> viewEmployee();

	Employee deleteEmployee(String empId);

	Employee updateEmployee(String empId, Employee employee);

}
