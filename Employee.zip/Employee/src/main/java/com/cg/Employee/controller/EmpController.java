package com.cg.Employee.controller;

import java.util.List;

import javax.validation.Valid;
import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.Employee.bean.Employee;
import com.cg.Employee.service.IService;

@RestController
@RequestMapping("/employee")
public class EmpController {

	@Autowired
	IService service;
	
	@RequestMapping(value="/create",method=RequestMethod.POST)
	public Employee addEmployee(@Valid @RequestBody Employee employee)
	{
		return service.addEmployee(employee);
	}
	
	@RequestMapping(value="/read",method=RequestMethod.GET)
	public List<Employee> viewEmployee()
	{
		return service.viewEmployee();
	}
	
	@RequestMapping(value="/delete/{empId}",method=RequestMethod.DELETE)
	public Employee deleteEmployee(@PathVariable String empId)
	{
		return service.deleteEmployee(empId);
	}
	
	@RequestMapping(value="/update/{empId}",method=RequestMethod.PUT)
	public Employee updateEmployee(@PathVariable String empId,@RequestBody Employee employee)
	{
		return service.updateEmployee(empId,employee);
	}
}
